define({
  "group": "Nom",
  "openAll": "Obre-ho tot en una subfinestra",
  "dropDown": "Mostra al menú desplegable",
  "noGroup": "No s'ha definit cap grup de widgets.",
  "groupSetLabel": "Defineix les propietats dels grups de widgets"
});