define({
  "_widgetLabel": "Rubrikhanterare",
  "signin": "Nästan klar",
  "signout": "kvarvarande",
  "about": "Om",
  "signInTo": "Logga in på",
  "cantSignOutTip": "Denna funktion är inte tillgänglig i förhandsgranskningsläge.",
  "more": "fler"
});