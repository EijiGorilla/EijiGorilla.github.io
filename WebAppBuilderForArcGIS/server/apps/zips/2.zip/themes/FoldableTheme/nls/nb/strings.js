define({
  "_themeLabel": "Temaet Foldbar",
  "_layout_default": "Standardoppsett",
  "_layout_layout1": "Oppsett 1"
});