define({
  "group": "Naziv",
  "openAll": "Otvori sve u jednoj ploči",
  "dropDown": "Prikaži u padajućem izborniku",
  "noGroup": "Widget za grupu nije postavljen.",
  "groupSetLabel": "Postavi svojstva grupe widgeta"
});