define({
  "_themeLabel": "折叠式主题",
  "_layout_default": "默认布局",
  "_layout_layout1": "布局 1"
});