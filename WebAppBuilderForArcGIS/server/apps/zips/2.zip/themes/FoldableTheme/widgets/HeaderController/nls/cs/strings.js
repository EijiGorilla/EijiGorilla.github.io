define({
  "_widgetLabel": "Ovladač záhlaví",
  "signin": "Přihlásit",
  "signout": "Odhlásit se",
  "about": "O aplikaci",
  "signInTo": "Přihlásit se do",
  "cantSignOutTip": "Tato funkce není v režimu náhledu k dispozici.",
  "more": "více"
});