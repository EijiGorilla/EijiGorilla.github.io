define({
  "_themeLabel": "ธีมพับ",
  "_layout_default": "เค้าโครงเริ่มต้น",
  "_layout_layout1": "โครงร่าง 1"
});